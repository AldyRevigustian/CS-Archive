#include <stdio.h>

int main(){
    int T;
    scanf("%d", &T);

    for(int i = 1; i <= T; i++){
        int N, M;
        scanf("%d %d", &N, &M);
        for(int j = 0; j < N; j++){
            for(int j = 0, i )
        }
		printf("Case #%d:\n", i);
        
    }
    return 0;
}
