#include <stdio.h>
#include <string.h>

struct  Mahasiswa
{
    char nama[50];
    char nim[20];
    int umur;
};

union Siswa
{
    char nama[50];
    char nim[20];
    int umur;
};

void writeFile(char nama[100], int umur){
    FILE *fp = fopen("mahasiswa.txt", "w");

    fprintf(fp, "%s#%d\n", nama, umur);
    fclose(fp);
}

void readFile(){
    FILE *fp = fopen("mahasiswa.txt", "r");

    if (fp == NULL)
    {
        printf("File No Found\n");
    }else{
        while (!feof(fp))
        {
            char nama[100];
            int umur;
            fscanf(fp, "%[^#]#%d\n", nama, &umur);
            printf("Nama : %s Umur : %d\n", nama, umur);
        }
        
    }
    fclose(fp);
}

void writeFile(char nama[100], int umur){
    FILE *fp = fopen("mahasiswa.txt", "a");

    fprintf(fp, "%s#%d\n", nama, umur);
    fclose(fp);
}

int main(){
	// Mahasiswa mahasiswa1;
    
	// strcpy(mahasiswa1.nama, "Aldey");
    // strcpy(mahasiswa1.nim, "2022");
    // mahasiswa1.umur = 20;
    

    // Mahasiswa mahasiswa2 = {"Revi", "202022", 19};

    // printf("Nama : %s NIM : %s Umur : %d\n", mahasiswa1.nama, mahasiswa1.nim, mahasiswa1.umur);
    // printf("Nama : %s NIM : %s Umur : %d\n", mahasiswa2.nama, mahasiswa2.nim, mahasiswa2.umur);

    // Siswa siswa;
    // strcpy(siswa.nama, "Aldey");

    // printf("Nama : %s\n", siswa.nama);
    // printf("%d %d", sizeof(Mahasiswa), sizeof(Siswa));

    writeFile("Aldy", 18);
    writeFile("Aldy", 18);
    readFile();
    return 0;
}
